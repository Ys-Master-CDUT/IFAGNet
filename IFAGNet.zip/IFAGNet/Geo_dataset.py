# coding:utf-8
# Modified by Yuxiang Sun, Aug. 2, 2019
# Email: sun.yuxiang@outlook.com

import os
import torch
from torch.utils.data.dataset import Dataset
from torch.utils.data import DataLoader
import numpy as np
#from PIL import Image
import math
from PIL import Image, ImageStat, ImageEnhance
import cv2
import matplotlib.pyplot as plt

def gasuss_noise(image, mean=0, var=0.001):
    """
        添加高斯噪声
        mean : 均值
        var : 方差
    """
    image = np.array(image/255, dtype=float)
    noise = np.random.normal(mean, var ** 0.5, image.shape)
    out = image + noise
    if out.min() < 0:
        low_clip = -1.
    else:
        low_clip = 0.
    out = np.clip(out, low_clip, 1.0)
    out = np.uint8(out*255)

    return out

def contrast_brightness(image):            # 定义方法， c @ contrast  对比度 ; b @ brightness 亮度
    h, w, ch = image.shape
    blank = np.zeros([h, w, ch], image.dtype)         # 定义一张空白图像
    c = np.random.randint(low=1, high=20)
    contrast=c//10    
    dst = cv2.addWeighted(image, contrast, blank, 1-contrast, 0)     # 设定权重
    return dst

def Gblur(image):            # 定义方法， c @ contrast  对比度 ; b @ brightness 亮度

    d = np.random.randint(low=0, high=2)
    if d == 0:
        dst = cv2.GaussianBlur(image, (3, 3), 0)     # 设定权重
    if d == 1:
        dst = cv2.GaussianBlur(image, (5, 5), 0) 
    if d == 2:
        dst = cv2.GaussianBlur(image, (7, 7), 0)     
    return dst



def concat(img,fuse,label):            # 定义方法， c @ contrast  对比度 ; b @ brightness 亮度

    c = np.random.randint(low=0, high=7)
       
    img2 = cv2.flip(img, 1)
    fuse2 = cv2.flip(fuse, 1)           
    label2 = cv2.flip(label, 1)               
    
    if c == 0:        
        joint1 = np.hstack((img,img))
        joint2 = np.hstack((fuse,fuse))        
        joint3 = np.hstack((label,label))
    if c == 1:              
        joint1 = np.hstack((img2,img2))
        joint2 = np.hstack((fuse2,fuse2))        
        joint3 = np.hstack((label2,label2))             
    if c == 2:       
        joint1 = np.hstack((img,img2))
        joint2 = np.hstack((fuse,fuse2))        
        joint3 = np.hstack((label,label2))
    if c == 3:       
        joint1 = np.hstack((img2,img))
        joint2 = np.hstack((fuse2,fuse))        
        joint3 = np.hstack((label2,label))             
    if c == 4:        
        joint1 = np.vstack((img,img))
        joint2 = np.vstack((fuse,fuse))        
        joint3 = np.vstack((label,label))
    if c == 5:              
        joint1 = np.vstack((img2,img2))
        joint2 = np.vstack((fuse2,fuse2))        
        joint3 = np.vstack((label2,label2))             
    if c == 6:       
        joint1 = np.vstack((img,img2))
        joint2 = np.vstack((fuse,fuse2))        
        joint3 = np.vstack((label,label2))
    if c == 7:       
        joint1 = np.vstack((img2,img))
        joint2 = np.vstack((fuse2,fuse))        
        joint3 = np.vstack((label2,label))     
  
    return joint1,joint2,joint3

def concat1(img,fuse):            # 定义方法， c @ contrast  对比度 ; b @ brightness 亮度

    c = np.random.randint(low=0, high=7)
       
    img2 = cv2.flip(img, 1)
    fuse2 = cv2.flip(fuse, 1)           
              
    
    if c == 0:        
        joint1 = np.hstack((img,img))
        joint2 = np.hstack((fuse,fuse))        

    if c == 1:              
        joint1 = np.hstack((img2,img2))
        joint2 = np.hstack((fuse2,fuse2))        
             
    if c == 2:       
        joint1 = np.hstack((img,img2))
        joint2 = np.hstack((fuse,fuse2))        

    if c == 3:       
        joint1 = np.hstack((img2,img))
        joint2 = np.hstack((fuse2,fuse))        
             
    if c == 4:        
        joint1 = np.vstack((img,img))
        joint2 = np.vstack((fuse,fuse))        

    if c == 5:              
        joint1 = np.vstack((img2,img2))
        joint2 = np.vstack((fuse2,fuse2))        
             
    if c == 6:       
        joint1 = np.vstack((img,img2))
        joint2 = np.vstack((fuse,fuse2))        

    if c == 7:       
        joint1 = np.vstack((img2,img))
        joint2 = np.vstack((fuse2,fuse))        
     
 
    return joint1,joint2

def cutout(img1,img2,label):

    h, w, ch = img1.shape[0:3]


            #正方形区域中心点随机出现
    ct = np.random.randint(low=0, high=1)
    if ct ==0:           
        y = np.random.randint(h)
        x = np.random.randint(w)
            #划出正方形区域，边界处截断
        y1 = y - 256
        y2 = y + 256
        x1 = x - 256
        x2 = x + 256
            #全0填充区域
        img1[y1: y2, x1: x2] = [0, 0, 0, 0]
        img2[y1: y2, x1: x2] = [0, 0, 0]
        label[y1: y2, x1: x2] = [0]      
    if ct ==1:           
        yf = np.random.randint(h)
        xf = np.random.randint(w)
            #划出正方形区域，边界处截断
        y1f = yf - 128
        y2f = yf + 128
        x1f = xf - 128
        x2f = xf + 128
            #全0填充区域
        img1[y1f: y2f, x1f: x2f] = [0, 0, 0, 0]
        img2[y1f: y2f, x1f: x2f] = [0, 0, 0]
        label[y1f: y2f, x1f: x2f] = [0]

        ys = np.random.randint(h)
        xs = np.random.randint(w)
            #划出正方形区域，边界处截断
        y1s = ys - 64
        y2s = ys + 64
        x1s = xs - 64
        x2s = xs + 64
            #全0填充区域
        img1[y1s: y2s, x1s: x2s] = [0, 0, 0, 0]
        img2[y1s: y2s, x1s: x2s] = [0, 0, 0]
        label[y1s: y2s, x1s: x2s] = [0]        
        
        yt = np.random.randint(h)
        xt = np.random.randint(w)
            #划出正方形区域，边界处截断
        y1t = yt - 32
        y2t = yt + 32
        x1t = xt - 32
        x2t = xt + 32
            #全0填充区域
        img1[y1t: y2t, x1t: x2t] = [0, 0, 0, 0]
        img2[y1t: y2t, x1t: x2t] = [0, 0, 0]
        label[y1t: y2t, x1t: x2t] = [0]  
    
    return img1,img2,label

class Geo_dataset(Dataset):

    def __init__(self, data_dir, split, have_label, input_h=512, input_w=512,transform=True):
        super(Geo_dataset, self).__init__()

        assert split in ['train','val', 'test'], 'split must be "train"|"val"|"test"|"test_day"|"test_night"|"val_test"'  # test_day, test_night

        with open(os.path.join(data_dir, split+'.txt'), 'r') as f:
            self.names = [name.strip() for name in f.readlines()]

        self.data_dir  = data_dir
        self.split     = split
        self.input_h   = input_h
        self.input_w   = input_w
        self.transform = transform
        self.have_label  = have_label
        self.n_data    = len(self.names)

    def read_image1(self, name, folder):
        file_path = os.path.join(self.data_dir, '%s/%s.png' % (folder, name))       
        image    = np.asarray(Image.open(file_path).convert('RGB')) # (w,h,c)
        return image
    def read_image(self, name, folder):
        file_path = os.path.join(self.data_dir, '%s/%s.png' % (folder, name))       
        image    = np.asarray(Image.open(file_path)) # (w,h,c)
        #image    = np.asarray(Image.open(file_path).convert('RGB')) # (w,h,c)
        return image
    
    def get_train_item(self, index):
        name  = self.names[index]
        image = self.read_image(name, 'images')               
        Fuse = self.read_image(name, 'fusion')
        
        if self.have_label==True:                 
            label = self.read_image(name, 'Label')


        
        flip = np.random.randint(low=0, high=4)
        if flip == 1:
            image = cv2.flip(image, 1)
            Fuse = cv2.flip(Fuse, 1)
            if self.have_label==True:             
                label = cv2.flip(label, 1)
        if flip == 2:
            image = cv2.flip(image, 0)
            Fuse = cv2.flip(Fuse, 0)
            if self.have_label==True:             
                label = cv2.flip(label, 0)                
        if flip == 3:
            image = cv2.flip(image, -1)
            Fuse = cv2.flip(Fuse, -1)
            if self.have_label==True:             
                label = cv2.flip(label, -1)                  
        

        if self.transform==True: 
            start_x = np.random.randint(low=0, high=(self.input_w- 256))
            end_x = start_x + 512
            start_y = np.random.randint(low=0, high=(self.input_h - 96))
            end_y = start_y + 512

            image = image[start_y:end_y, start_x:end_x] # (shape: (768, 768, 3))
            Fuse = Fuse[start_y:end_y, start_x:end_x] # (shape: (768, 768, 3))
            if self.have_label==True:              
                label= label[start_y:end_y, start_x:end_x] # (shape: (768, 768))
            
            if self.have_label==True:  
                image,Fuse,label = concat(image,Fuse,label)
            else:
                image,Fuse = concat1(image,Fuse)
        
        if self.transform==True:
            blur = np.random.randint(low=0, high=2)
            if blur == 1:
                image = Gblur(image)
                Fuse = Gblur(Fuse)        
        
   
        
        image = np.asarray(Image.fromarray(image).resize((self.input_w, self.input_h)), dtype=np.float32).transpose((2,0,1))/255                    
        
        Fuse = np.asarray(Image.fromarray(Fuse).resize((self.input_w, self.input_h)), dtype=np.float32).transpose((2,0,1))/255
        
        if self.have_label==True:        
            label = np.asarray(Image.fromarray(label).resize((self.input_w, self.input_h)), dtype=np.int64)   
            return torch.tensor(image), torch.tensor(Fuse), torch.tensor(label), name

        else:
            return torch.tensor(image), torch.tensor(Fuse), name




    def __getitem__(self, index):

        #if self.is_train is True:
        return self.get_train_item(index)
        #else: 
            #return self.get_test_item (index)

    def __len__(self):
        return self.n_data

