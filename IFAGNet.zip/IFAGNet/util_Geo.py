# coding:utf-8
import numpy as np 
from PIL import Image 
import cv2 
# 0:unlabeled, 1:car, 2:person, 3:bike, 4:curve, 5:car_stop, 6:guardrail, 7:color_cone, 8:bump 

def get_palette():
    unlabelled = [0,0,0]
    target        = [255,0,128]
    palette    = np.array([unlabelled,target])
    return palette

def visualize1(image_name, predictions):
    palette = get_palette()
    for (i, pred) in enumerate(predictions):       
        
        pred = predictions[i].cpu().numpy()
        
        img = np.zeros((pred.shape[0], pred.shape[1], 3), dtype=np.uint8)
        for cid in range(0, len(palette)): # fix the mistake from the MFNet code on Dec.27, 2019
            img[pred == cid] = palette[cid]
        img = Image.fromarray(np.uint8(img))         
        img.save('Geo_results1/Pred_' + '_' + image_name)



def visualize2(image_name, predictions):
    palette = get_palette()
    for (i, pred) in enumerate(predictions):       
        
        pred = predictions[i].cpu().numpy()
        
        img = np.zeros((pred.shape[0], pred.shape[1], 3), dtype=np.uint8)
        for cid in range(0, len(palette)): # fix the mistake from the MFNet code on Dec.27, 2019
            img[pred == cid] = palette[cid]
        img = Image.fromarray(np.uint8(img))         
        img.save('Geo_results2/Pred_' + '_' + image_name)

def visualize3(image_name, predictions):
    palette = get_palette()
    for (i, pred) in enumerate(predictions):       
        
        pred = predictions[i].cpu().numpy()
        
        img = np.zeros((pred.shape[0], pred.shape[1], 3), dtype=np.uint8)
        for cid in range(0, len(palette)): # fix the mistake from the MFNet code on Dec.27, 2019
            img[pred == cid] = palette[cid]
        img = Image.fromarray(np.uint8(img))         
        img.save('Geo_results3/Pred_' + '_' + image_name)        

def visualize_overlay(image_name, imgs,predictions):
    palette = get_palette()
    for (i, pred) in enumerate(predictions):
         
        imgo = imgs[i].data.cpu().numpy()
        imgo = np.transpose(imgo, (1, 2, 0)) # (shape: (img_h, img_w, 3))
        #imgo = imgo*np.array([0.229, 0.224, 0.225])
        #imgo = imgo + np.array([0.485, 0.456, 0.406])
        imgo = imgo*255.0
        imgo = imgo.astype(np.uint8)        
        
        pred = predictions[i].cpu().numpy()
        
        img = np.zeros((pred.shape[0], pred.shape[1], 3), dtype=np.uint8)
        for cid in range(0, len(palette)): # fix the mistake from the MFNet code on Dec.27, 2019
            img[pred == cid] = palette[cid]
        #img = Image.fromarray(np.uint8(img))
        
        overlayed_img = 0.5*imgo + 0.5*img
        overlayed_img = overlayed_img.astype(np.uint8)
        overlayed_img= Image.fromarray(overlayed_img)        
        
        overlayed_img.save('Geo_results_o/Pred_' + '_' + image_name)

def compute_results(conf_total):
    n_class =  conf_total.shape[0]
    consider_unlabeled = True  # must consider the unlabeled, please set it to True
    if consider_unlabeled is True:
        start_index = 0
    else:
        start_index = 1
    precision_per_class = np.zeros(n_class)
    recall_per_class = np.zeros(n_class)
    iou_per_class = np.zeros(n_class)
    for cid in range(start_index, n_class): # cid: class id
        if conf_total[start_index:, cid].sum() == 0:
            precision_per_class[cid] =  np.nan
        else:
            precision_per_class[cid] = float(conf_total[cid, cid]) / float(conf_total[start_index:, cid].sum()) # precision = TP/TP+FP
        if conf_total[cid, start_index:].sum() == 0:
            recall_per_class[cid] = np.nan
        else:
            recall_per_class[cid] = float(conf_total[cid, cid]) / float(conf_total[cid, start_index:].sum()) # recall = TP/TP+FN
        if (conf_total[cid, start_index:].sum() + conf_total[start_index:, cid].sum() - conf_total[cid, cid]) == 0:
            iou_per_class[cid] = np.nan
        else:
            iou_per_class[cid] = float(conf_total[cid, cid]) / float((conf_total[cid, start_index:].sum() + conf_total[start_index:, cid].sum() - conf_total[cid, cid])) # IoU = TP/TP+FP+FN

    return precision_per_class, recall_per_class, iou_per_class
