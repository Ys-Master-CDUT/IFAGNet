# camera-ready
#from datasetFLR import DatasetTrain, DatasetVal # (this needs to be imported before torch, because cv2 needs to be imported before torch for some reason)




from efficientvit import EVIT

import torch
import torch.utils.data
import torch.nn as nn
from torch.autograd import Variable
import torch.optim as optim
import torch.nn.functional as F
from loss import FocalLossM,,SoftDiceLoss
from loss import FocalTversky_loss
import numpy as np
import pickle
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import cv2
import time
from tqdm import tqdm, trange
import Geo_dataset


import os
os.environ["CUDA_DEVICE_ORDER"] = "PCI_BUS_ID"
os.environ["CUDA_VISIBLE_DEVICES"] = "0,1,2,3,4,5"



if __name__ == "__main__":

    model_id = "1"

    num_epochs = 1000
    batch_size1 = 12
    batch_size2 = 12
    
    #learning_rate = 0.0001
    learning_rate = 0.001
    #learning_rate = 0.01   

    data_dir  = './dataset_GeoF/'

    network = EVIT()


    
    device_ids = [i for i in range(torch.cuda.device_count())]

    print("\n\nLet's use", torch.cuda.device_count(), "GPUs!\n\n")

    network = nn.DataParallel(network, device_ids = device_ids)
    network = network.cuda(device=device_ids[0])  # 模型放在主设备

      
        
    
    train_dataset = Geo_dataset(data_dir, 'train', have_label=True, transform=True)
    val_dataset = Geo_dataset(data_dir, 'val', have_label=True, transform=False)

    num_train_batches = int(len(train_dataset)/batch_size1)
    num_val_batches = int(len(val_dataset)/batch_size2)
    print ("num_train_batches:", num_train_batches)
    print ("num_val_batches:", num_val_batches)

    train_loader = torch.utils.data.DataLoader(dataset=train_dataset,
                                            batch_size=batch_size1, shuffle=True,
                                            num_workers=12,drop_last=True)
    val_loader = torch.utils.data.DataLoader(dataset=val_dataset,
                                            batch_size=batch_size2, shuffle=False,
                                            num_workers=12,drop_last=True)

    optimizer = torch.optim.Adam(network.parameters(), lr=learning_rate)

    # loss function

    loss_fn1 = FocalLossM()
    loss_fn2 = SoftDiceLoss()

    epoch_losses_train = []
    epoch_losses_val = []
    for epoch in range(num_epochs):
        print ("###########################")
        print ("######## NEW EPOCH ########")
        print ("###########################")
        print ("epoch: %d/%d" % (epoch+1, num_epochs))
        

        ############################################################################
        # train:
        ############################################################################
        network.train() # (set in training mode, this affects BatchNorm and dropout)
        batch_losses = []
        for step, (images, fusion, labels, names) in tqdm(enumerate(train_loader)):
            #current_time = time.time()                        
            imgs = Variable(images).cuda(device=device_ids[0]) # (shape: (batch_size, 3, img_h, img_w))

            Fuse = Variable(fusion).cuda(device=device_ids[0]) # (shape: (batch_size, 3, img_h, img_w))            

            # print(imgs.shape)
            label_imgs = Variable(labels.type(torch.LongTensor)).cuda(device=device_ids[0]) # (shape: (batch_size, img_h, img_w))
            # print(label_imgs.shape)
            output1, output2,output3 = network(imgs,Fuse)



            # compute the loss:
          
            loss1 = loss_fn1(output1, label_imgs)+0.02*loss_fn2(output1, label_imgs)
            loss2 = loss_fn1(output2, label_imgs)+0.02*loss_fn2(output2, label_imgs)
            loss3 = loss_fn1(output3, label_imgs)+0.02*loss_fn2(output3, label_imgs)
            loss4 = loss_fn1(output, label_imgs)+0.02*loss_fn2(output, label_imgs)
            
            loss5 = loss_fn1(output3, output1.argmax(1))+0.02*loss_fn2(output3, output1.argmax(1))            
            loss6 = loss_fn1(output3, output2.argmax(1))+0.02*loss_fn2(output3, output2.argmax(1))
            loss7 = loss_fn1(output1, output3.argmax(1))+0.02*loss_fn2(output1, output3.argmax(1))
            loss8 = loss_fn1(output2, output3.argmax(1))+0.02*loss_fn2(output2, output3.argmax(1))                                       

            loss = loss1+loss2+loss3+loss4+loss5+loss6+loss7+loss8
            

            loss_value = loss.data.cpu().numpy()
            batch_losses.append(loss_value)

            #optimization step:
            optimizer.zero_grad() # (reset gradients)
            loss.backward() # (compute gradients)
            optimizer.step() # (perform optimization step)
            


        epoch_loss = np.mean(batch_losses)
        epoch_losses_train.append(epoch_loss)
        with open("%s/epoch_losses_train.pkl" % "trainning_log", "wb") as file:
            pickle.dump(epoch_losses_train, file)
        print ("train loss: %g" % epoch_loss)
        plt.figure(1)
        plt.plot(epoch_losses_train, "k^")
        plt.plot(epoch_losses_train, "k")
        plt.ylabel("loss")
        plt.xlabel("epoch")
        plt.title("train loss per epoch")
        plt.savefig("%s/epoch_losses_train.png" % "trainning_log")
        plt.close(1)
        #print (learning_rate)
        print ("####")

        ############################################################################
        # val:
        ############################################################################
        network.eval() # (set in evaluation mode, this affects BatchNorm and dropout)
        batch_losses = []
        for step, (images, fusion, labels, names) in tqdm(enumerate(val_loader)):
            with torch.no_grad(): # (corresponds to setting volatile=True in all variables, this is done during inference to reduce memory consumption)
                imgs = Variable(images).cuda(device=device_ids[0]) # (shape: (batch_size, 3, img_h, img_w))

                Fuse = Variable(fusion).cuda(device=device_ids[0]) # (shape: (batch_size, 3, img_h, img_w)) 
                label_imgs = Variable(labels.type(torch.LongTensor)).cuda(device=device_ids[0]) # (shape: (batch_size, img_h, img_w))

                output1,output2,output3 = network(imgs,Fuse) # (shape: (batch_size, num_classes, img_h, img_w))



            # compute the loss:
                        
                
                loss1 = loss_fn1(output1, label_imgs)+0.02*loss_fn2(output1, label_imgs)
                loss2 = loss_fn1(output2, label_imgs)+0.02*loss_fn2(output2, label_imgs)
                loss3 = loss_fn1(output3, label_imgs)+0.02*loss_fn2(output3, label_imgs)
                loss4 = loss_fn1(output, label_imgs)+0.02*loss_fn2(output, label_imgs)
            
                loss5 = loss_fn1(output3, output1.argmax(1))+0.02*loss_fn2(output3, output1.argmax(1))            
                loss6 = loss_fn1(output3, output2.argmax(1))+0.02*loss_fn2(output3, output2.argmax(1))
                loss7 = loss_fn1(output1, output3.argmax(1))+0.02*loss_fn2(output1, output3.argmax(1))
                loss8 = loss_fn1(output2, output3.argmax(1))+0.02*loss_fn2(output2, output3.argmax(1))                                       

                loss = loss1+loss2+loss3+loss4+loss5+loss6+loss7+loss8

                loss_value = loss.data.cpu().numpy()
                batch_losses.append(loss_value)

        epoch_loss = np.mean(batch_losses)
        epoch_losses_val.append(epoch_loss)
        with open("%s/epoch_losses_val.pkl" % "trainning_log", "wb") as file:
            pickle.dump(epoch_losses_val, file)
        print ("val loss: %g" % epoch_loss)
        plt.figure(1)
        plt.plot(epoch_losses_val, "k^")
        plt.plot(epoch_losses_val, "k")
        plt.ylabel("loss")
        plt.xlabel("epoch")
        plt.title("val loss per epoch")
        plt.savefig("%s/epoch_losses_val.png" % "trainning_log")
        plt.close(1)

        # save the model weights to disk:
        if epoch % 50 == 0:
            checkpoint_path = "trainning_log" + "/model"  +"EVITGeo" +str(epoch) + ".pth"
            torch.save(network.state_dict(), checkpoint_path)
           
