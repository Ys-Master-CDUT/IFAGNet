# camera-ready



from efficientvit import EVIT

import torch
import torch.utils.data
import torch.nn as nn
from torch.autograd import Variable
import torch.optim as optim
import torch.nn.functional as F
from PIL import Image
from torch.autograd import Variable
from util_Geo import visualize1,visualize2,visualize3
import numpy as np
import pickle
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import cv2
import time
import os
os.environ["CUDA_DEVICE_ORDER"] = "PCI_BUS_ID"
os.environ["CUDA_VISIBLE_DEVICES"] = "0,1,2,3,4,5"

if __name__ =="__main__":

    batch_size = 1


    network = EVIT()


    device_ids = [i for i in range(torch.cuda.device_count())]

    print("\n\nLet's use", torch.cuda.device_count(), "GPUs!\n\n")

    network = nn.DataParallel(network, device_ids = device_ids)
    network = network.cuda(device=device_ids[0])  # 模型放在主设备
    network.load_state_dict(torch.load("trainning_log/modelEVITGeobest.pth"))

    

    
    
    
    image_dir1 = './dataset_GeoF/testimage/images/'

    image_dir2 = './dataset_GeoF/testimage/fusion/'    
    

    
    su=0
    i=0
    files = os.listdir(image_dir1)
    for file in files:
        if file[-3:] != 'png': continue
        if 'flip' in file: continue
        
        image = np.asarray(Image.open(image_dir1+file))
        image = cv2.resize(image,(512,512),interpolation = cv2.INTER_AREA)
        image = torch.from_numpy(image).float()
        image.unsqueeze_(0)
        image = np.asarray(image, dtype=np.float32).transpose((0,3,1,2))/255.0        
        
       
        
        fuse = np.asarray(Image.open(image_dir2+file))
        fuse = cv2.resize(fuse,(512,512),interpolation = cv2.INTER_AREA)
        fuse = torch.from_numpy(fuse).float()
        fuse.unsqueeze_(0)        
        fuse = np.asarray(fuse, dtype=np.float32).transpose((0,3,1,2))/255.0
                    

        fuse = Variable(torch.tensor(fuse)).cuda()
        image = Variable(torch.tensor(image)).cuda()                 
        
        network.eval()


        with torch.no_grad():
   
            
            start_time = time.time()

            output1,output2,output3 = network(image,fuse)

            predictions1 = output1.argmax(1)
            predictions2 = output2.argmax(1)
            predictions3 = output.argmax(1)
            
            end_time = time.time()
            print('cost %f s' % (end_time - start_time))                        
            
            visualize1(file,predictions1)
            visualize2(file,predictions2)
            visualize3(file,predictions3)
            
            cs=end_time - start_time
            i+=1
        if(i>0):
            su+=cs
                       
        print('| %s:%s, prediction of %s has been saved in ./demo_results')
    print('average cost %f s' % (su//i))
