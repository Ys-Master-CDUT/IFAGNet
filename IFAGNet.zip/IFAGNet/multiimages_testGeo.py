"""
多张图测试
"""
"""
1、先根据标签图像找到对应的测试图像
2、将上色图像恢复为单通道图像
3、混淆矩阵相加求解指标
"""
import semseg_metrics as metrics
import numpy as np
import cv2 as cv
import os
from tqdm import tqdm
import torch
import torch.nn as nn
# function for colorizing a label image:
def label_img_to_color(img):
    label_to_color = {
        0: [0, 0, 0],
        1: [255,0,128]
        }

    img_height, img_width = img.shape
    #img_height, img_width = 512
    # print(img.shape)
    # img_height, img_width = img.shape[1],img.shape[2]

    img_color = np.zeros((img_height, img_width, 3))
    for row in range(img_height):
        for col in range(img_width):
            label = img[row, col]

            img_color[row, col] = np.array(label_to_color[label])

    return img_color

n_labels=2
confusion_matrix = np.zeros((n_labels, n_labels), dtype=int)

def find_index(label_to_color,color):
    for i in range(len(label_to_color)):
        if all(color == label_to_color[i]):
            return i



def color_img_to_label(img):
    """
    用于将三通道图像
    通过颜色查找表，映射回单通道图像
    """
    #label_to_color = [[0, 0, 0],[64,0,128],[64,64,0],[0,128,192],[0,0,192],[128,128,0],[64,64,128],[192,128,128],[192,64,0]]
    label_to_color = [[0, 0, 0],[128,0,255]]

    img_height, img_width, _ = img.shape
    label_img = np.zeros((img_height, img_width))
    # print(label_img.shape)
    for row in range(img_height):
        for col in range(img_width):
            color = img[row, col]
            index = find_index(label_to_color,color)
            # print(color,index)
            label_img[row, col] = index

    return label_img

gt_img_dir = "./dataset_Geo/testlabel/" # 设置标签文件夹路径
test_img_dir = "./Geo_results1/" # 设置检测文件夹路径
gt_file_names = os.listdir(gt_img_dir)
for gt_file_name in tqdm(gt_file_names):
    # 先根据标签图像找到对应的测试图像
    img_id =  gt_file_name.split(".png")[0]
    gt_img_path = gt_img_dir +img_id + ".png"
    #test_img_path = test_img_dir + img_id + ".png"
    test_img_path = test_img_dir +'Pred_'+'_'+img_id + ".png"
    # 将上色图像恢复为单通道图像
    gt_img = cv.imread(gt_img_path) 
    gt_img = cv.resize(gt_img,(512,512))
    #print(gt_img)     
    gt_img = cv.cvtColor(gt_img,cv.COLOR_BGR2GRAY)
    #gt_img = label_img_to_color(gt_img)
    # print(gt_img.shape)
    #gt_img = color_img_to_label(gt_img)
    #print(gt_img)    
    #print(gt_img.shape)

    test_img = cv.imread(test_img_path) 
    #test_img = cv.resize(test_img,(640,480))
    # print(test_img.shape)
    test_img = color_img_to_label(test_img)
    #print(test_img.shape)

    # pred and gt should be the same size and 1ch image

    confusion_matrix1 = np.zeros((n_labels, n_labels), dtype=int)
    ignore_labels = None

    confusion_matrix += metrics.calc_confusion_matrix(test_img, gt_img, confusion_matrix1)




print("##########################")
print("##########Final result:########")
print("##########################")

print('PA:', metrics.calc_pixel_accuracy(confusion_matrix, ignore_labels))#Accuracy(PA)
print('cPA:', metrics.calc_mean_precision(confusion_matrix, ignore_labels)[1])#Precision
print('mPA:', metrics.calc_mean_precision(confusion_matrix, ignore_labels)[0])
print('cRecall:', metrics.calc_mean_recall(confusion_matrix, ignore_labels)[1])#Recall
print('mRecall:', metrics.calc_mean_recall(confusion_matrix, ignore_labels)[0])
print('cIoU:', metrics.calc_mean_IoU(confusion_matrix, ignore_labels)[1])#IoU
print('mIoU:', metrics.calc_mean_IoU(confusion_matrix, ignore_labels)[0])
print('cF1-Score:', metrics.calc_class_F1_scores(confusion_matrix, ignore_labels))#F1-score
print('mF1-Score:', metrics.calc_mean_F1_score(confusion_matrix, ignore_labels))

